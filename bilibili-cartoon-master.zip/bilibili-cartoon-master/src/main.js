import Vue from "vue";
import "./plugins/axios";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./assets/css/reset.css";
import "@/assets/css/incofont.css";
import VueTouch from "vue-touch";
// import imgloading from "./assets/images/loading.jpg";
Vue.use(VueTouch, { name: "v-touch" });

import "vant/lib/index.css";
import {
    Swipe,
    SwipeItem,
    Lazyload,
    Loading,
    Dialog,
    Tabbar,
    TabbarItem,
    Search,
    Tab,
    Tabs,
    TreeSelect,
    Image as VanImage,
    Field,
    Cell,
    CellGroup,
    Button,
    Switch,
    Popup,
} from "vant";
Vue.use(Swipe)
    .use(SwipeItem)
    .use(Loading)
    .use(Dialog)
    .use(Tabbar)
    .use(TabbarItem)
    .use(Search)
    .use(Tab)
    .use(Tabs)
    .use(VanImage)
    .use(Field)
    .use(Cell)
    .use(CellGroup)
    .use(Button)
    .use(Switch)
    .use(Popup)
    .use(TreeSelect);

/* Vue.use(Lazyload, {
    loading: imgloading,
    error: imgloading,
}); */
Vue.use(Lazyload);

Vue.config.productionTip = false;

new Vue({
    router,
    store,
    render: (h) => h(App),
}).$mount("#app");
