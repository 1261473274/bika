import Vue from "vue";
import VueRouter from "vue-router";
import HomeView from "../views/HomeView.vue";

Vue.use(VueRouter);

const routes = [
    {
        path: "/",
        name: "home",
        component: HomeView,
    },
    {
        //排行榜
        path: "/ranking",
        name: "ranking",
        component: () => import("../views/RankingView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //免费
        path: "/feed",
        name: "feed",
        component: () => import("../views/FeedView.vue"),
        meta: {
            hideNav: true,
        },
    },

    {
        //分类
        path: "/classify",
        name: "classify",
        component: () => import("../views/ClassifyView.vue"),
    },
    {
        //漫画详情
        path: "/details/:id",
        name: "details",
        props: true,
        component: () => import("../views/DetailsView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //漫画章节内容
        path: "/chapters",
        name: "chapters",
        props: true,
        component: () => import("../views/ChaptersView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //收藏页面
        path: "/collect",
        name: "collect",
        component: () => import("../views/CollectView.vue"),
    },
    {
        //收藏页面
        path: "/user",
        name: "user",
        component: () => import("../views/UserView.vue"),
    },
    {
        //显示全部
        path: "/lookAll/:id/:title",
        name: "lookAll",
        props: true,
        component: () => import("../views/lookAll.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //搜索
        path: "/search",
        name: "search",
        component: () => import("../views/SearchView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //登录
        path: "/login",
        name: "login",
        component: () => import("../views/loginView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //登录
        path: "/setLogin",
        name: "setLogin",
        component: () => import("../views/setLogin.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //讨论页面
        path: "/discussion/:oid",
        name: "discussion",
        props: true,
        component: () => import("../views/DiscussionView.vue"),
        meta: {
            hideNav: true,
        },
    },
    {
        //讨论页面
        path: "/replyDetail/:rootId",
        name: "replyDetail",
        props: true,
        component: () => import("../views/ReplyDetail.vue"),
        meta: {
            hideNav: true,
        },
    },
];

const router = new VueRouter({
    mode: "hash",
    routes,
});
export default router;
