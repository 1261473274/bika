<template>
    <div>
        <!--   @search="onSearch"
            @cancel="onCancel" -->
        <div class="search">
            <van-search
                v-model="value"
                :placeholder="placeholder"
                show-action
                shape="round"
                :autofocus="true"
                @search="onSearch"
                @input="oninput"
                @cancel="cancel"
                class="search"
            />
        </div>
        <!-- 热门搜索 -->
        <div v-if="show">
            <div class="hot_search" v-if="!value">
                <div class="histor" v-if="searchHistor.length > 0">
                    <div class="title">
                        <h3>搜索历史</h3>
                        <div @click.stop="delHistor">
                            <img src="../assets/images/del.png" alt="" />
                        </div>
                    </div>
                    <div class="search_item">
                        <span v-for="(h, i) in searchHistor" :key="i" @click.stop="toResult(h)">{{
                            h
                        }}</span>
                    </div>
                </div>
                <h2>热门搜索</h2>
                <div class="search_list">
                    <router-link
                        :to="`/details/${item.season_id}`"
                        class="search_item"
                        v-for="(item, i) in SearchRecommend"
                        :key="item.season_id"
                    >
                        <div class="left">{{ i + 1 }}</div>
                        <div class="center">
                            <van-image
                                width="12vw"
                                height="15.2vw"
                                lazy-load
                                fit="cover"
                                :src="`${item.vertical_cover}@100w.jpg`"
                            />
                        </div>
                        <div class="right">
                            <p>{{ item.title }}</p>
                            <span v-for="(styles, i) in item.styles" :key="i"
                                >{{ styles }}&nbsp;&nbsp;</span
                            >
                        </div>
                    </router-link>
                </div>
            </div>
        </div>
        <div class="loading" v-if="isloading">
            <van-loading size="24px" vertical text-color="#0094ff" color="#0094ff"
                >加载中...</van-loading
            >
        </div>
        <!-- 搜索建议 -->
        <div v-if="show">
            <div class="search_suggest" v-if="value">
                <div class="search_list">
                    <div
                        class="search_item"
                        v-for="(item, i) in SearchSug"
                        :key="i"
                        @click.stop="suggestTo(item)"
                    >
                        <div class="image">
                            <img src="../assets/images/search.png" alt="" />
                        </div>
                        <div class="text" v-html="item"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="loading" v-if="isloading">
            <van-loading size="24px" vertical text-color="#0094ff" color="#0094ff"
                >加载中...</van-loading
            >
        </div>
        <!-- 搜索结果 -->
        <div v-if="isresult">
            <search-result ref="result" :keyword="value"></search-result>
        </div>
    </div>
</template>

<script>
import router from "@/router";
import _ from "lodash";
import SearchResult from "@/components/SearchResult.vue";
export default {
    components: { SearchResult },
    data() {
        return {
            value: "",
            placeholder: "",
            SearchRecommend: [], //热门搜索
            SearchSug: [], //搜索建议
            searchHistor: [],
            AllLabel: [], //分类筛选
            isresult: false,
            show: true,
            isloading: true,
        };
    },
    created() {
        this.getSearchRecommend();
        this.placeholder = this.$route.query.currentSwipe;
        let histor = JSON.parse(localStorage.getItem("searchHistor"));
        if (!histor) {
            this.searchHistor = [];
        } else {
            this.searchHistor = histor;
        }
    },
    methods: {
        oninput: _.debounce(function () {
            if (this.value == "") {
                this.show = true;
                this.isresult = false;
                return;
            }
            this.isloading = true;
            this.getSearchSug(this.value);
        }, 300),
        onSearch() {
            if (this.value == "") {
                this.value = this.placeholder;
            }

            this.searchHistor.push(this.value);
            this.searchHistor = _.uniq(this.searchHistor);
            localStorage.setItem("searchHistor", JSON.stringify(_.uniq(this.searchHistor)));
            if (this.isresult) {
                this.$refs.result.getSearchClassify();
            }
            this.isresult = true;
            this.show = false;
        },
        toResult(h) {
            this.value = h;
            this.onSearch();
        },
        suggestTo(value) {
            let str = this.value;
            let reg = new RegExp(`<em style="color:#32a9fb">${this.value}</em>`, "gi");
            this.value = value.replace(reg, str);
            this.onSearch();
        },
        //取消
        cancel() {
            router.back();
        },
        //删除
        delHistor() {
            localStorage.clear("searchHistor");
            this.searchHistor = [];
        },
        async getSearchRecommend() {
            await this.axios.get("SearchRecommend?num=10").then((res) => {
                this.SearchRecommend = res.splice(0, 6);
                this.isloading = false;
            });
        },
        async getSearchSug(value) {
            await this.axios.get(`SearchSug?term=${value}`).then((res) => {
                this.SearchSug = [];
                this.isloading = false;
                let arr = res.splice(",");
                let str = `style="color:#32a9fb"`;
                let reg = new RegExp(`class="keyword"`, "gi");
                arr.forEach((v) => {
                    this.SearchSug.push(v.replace(reg, str));
                });
            });
        },
    },
};
</script>

<style lang="scss" scoped>
.van-search--show-action {
    border-bottom: 1px solid #e9e9e9;
}
.serach {
    .van-field__body {
        font-size: 12px;
    }
    .van-search__action {
        padding: 0 15px;
    }
}
.hot_search {
    padding: 0px 15px;
    .histor {
        .title {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            h3 {
                color: #b9bcc0;
            }
            img {
                width: 14px;
                height: 16px;
            }
        }
        .search_item {
            display: flex;
            flex-wrap: wrap;
            span {
                padding: 5px 15px;
                margin: 10px 10px 0 0;
                background: #f0f0f2;
            }
        }
    }
    h2 {
        margin-top: 20px;
        margin-bottom: 15px;
        color: #b1b3b9;
        font-size: 14px;
    }
    .search_list {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        .search_item {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            width: 50%;
            padding: 10px 0;
            .left {
                width: 15%;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 26px;
                font-weight: bolder;
            }
            &:nth-child(1) {
                color: #e65857;
            }
            &:nth-child(2) {
                color: #e77f4b;
            }
            &:nth-child(3) {
                color: #f3ad27;
            }
            &:nth-child(4),
            &:nth-child(5),
            &:nth-child(6) {
                color: #bcbcbc;
            }
            .center {
                width: 25%;
                img {
                }
            }
            .right {
                width: 55%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                padding-left: 8px;
                p {
                    color: #515353;
                    font-size: 14px;
                    font-weight: bold;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                span {
                    color: #b1b3b9;
                    font-size: 12px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
            }
        }
    }
}
.search_suggest {
    .search_list {
        .search_item {
            display: flex;
            align-content: center;
            padding: 15px 0;
            border-bottom: 1px solid #e9e9e9;
            .image {
                img {
                    width: 20px;
                    height: 20px;
                    padding: 0 22px;
                }
            }
            .text {
                span {
                    color: #32a9fb;
                }
                color: #1a1e1f;
                .keyword {
                    color: #32a9fb;
                }
                .active {
                    color: #32a9fb;
                }
            }
        }
    }
}
.loading {
    position: absolute;
    left: 0;
    right: 0;
    top: 300px;
}
</style>
