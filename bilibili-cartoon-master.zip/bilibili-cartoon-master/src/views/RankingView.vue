<template>
    <div class="ranking">
        <div class="top_title">
            <span class="iconfont icon-fanhui" @click.stop="back"></span>
            排行
        </div>
        <div class="ranging_info" v-if="ListRank">
            <div class="left_nav">
                <div
                    v-for="(item, i) in ListRank"
                    :key="i"
                    :class="['nav_item', index == i ? 'active' : '']"
                    @click.stop="changeActive(i)"
                >
                    {{ item.name }}
                </div>
            </div>
            <div class="right_info">
                <div
                    v-for="(item, i) in ListRank"
                    :key="i"
                    :class="['right_content', index == i ? 'show' : '']"
                >
                    <div class="title">{{ item.description }}</div>
                    <ranking-list
                        v-if="rankInfo.length > 0"
                        :rankinglist="rankInfo[currentId]"
                    ></ranking-list>
                </div>
            </div>
        </div>
        <div class="loading" v-if="loading">
            <van-loading size="24px" vertical text-color="#0094ff" color="#0094ff"
                >加载中...</van-loading
            >
        </div>
    </div>
</template>

<script>
import RankingList from "@/components/RankingList.vue";
export default {
    components: { RankingList },
    data() {
        return {
            index: 3,
            ListRank: [],
            rankInfo: [],
            active: 0,
            currentId: 0,
            loading: true,
        };
    },
    created() {
        this.getListRank();
    },
    methods: {
        async getListRank() {
            await this.axios.get("ListRank").then((res) => {
                this.ListRank = res.list;

                this.GetRankInfo(this.ListRank[3].id);
            });
        },
        async GetRankInfo(id) {
            await this.axios.get(`GetRankInfo?id=${id}&offset=0&subId=0`).then((res) => {
                this.rankInfo.push(res.list);
                this.loading = false;
            });
        },
        changeActive(i) {
            this.index = i;
            let id = this.ListRank[i].id;
            this.currentId++;
            this.loading = true;
            this.GetRankInfo(id);
        },
        back() {
            history.back();
        },
    },
};
</script>
<style lang="scss" scoped>
.ranking {
    position: relative;

    .top_title {
        text-align: center;
        font-size: 16px;
        line-height: 45px;
        position: fixed;
        right: 0;
        left: 0;
        top: 0;
        z-index: 100;
        background: #fff;
        border-bottom: 1px solid #eee;
        span {
            position: absolute;
            left: 12px;
            top: 0;
            bottom: 0;
        }
    }
    ul {
        display: flex;
        text-align: center;
        margin: 12px 4px;
        li {
            width: 33%;
            line-height: 28px;
            span {
                font-size: 12px;
                color: #6c727e;
                background: #f5f7f8;
                border-radius: 14px;
                padding: 6px 18px;
            }
            .active {
                color: #ff5f8c;
                background: rgba(255, 95, 140, 0.08);
            }
        }
    }
    .ranging_info {
        // display: flex;
        overflow: hidden;
        .left_nav {
            position: fixed;
            left: 0;
            top: 50px;
            background: #fff;
            width: 22%;
            display: flex;
            text-align: center;
            flex-direction: column;
            padding: 0;
            margin: 0;
            .nav_item {
                width: 100%;
                line-height: 35px;
                margin: 10px 0;
                color: #999;
            }
            .active {
                background: #32aaff;
                color: #fff;
                border-top-right-radius: 20px;
                border-bottom-right-radius: 20px;
            }
        }
        .right_info {
            width: 78%;
            float: right;
            margin-top: 60px;
            .right_content {
                display: none;
                .title {
                    font-size: 12px;
                    color: #999;
                    text-align: center;
                    padding-bottom: 10px;
                }
            }
            .show {
                display: block;
            }
        }
    }
    .loading {
        position: absolute;
        top: 100px;
        left: 0;
        right: 0;
    }
}
</style>
