<template>
  <div>
    <ranking-list
      v-if="mangalist.length > 0"
      :rankinglist="mangalist"
    ></ranking-list>
    <van-loading
      v-if="$store.state.isloading"
      size="24px"
      vertical
      text-color="#0094ff"
      color="#0094ff"
      >加载中...</van-loading
    >
  </div>
</template>

<script>
import RankingList from "@/components/RankingList.vue";
// 1 free 3 manga 4 chinese
export default {
  components: { RankingList },
  data() {
    return {
      mangalist: [],
    };
  },
  created() {
    this.getMangaList();
  },
  methods: {
    async getMangaList() {
      await this.axios.get("GetRankInfo?id=0").then((res) => {
        this.mangalist = res.list;
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
