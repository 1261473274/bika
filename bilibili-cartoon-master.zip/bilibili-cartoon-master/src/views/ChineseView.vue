<template>
    <div>
        <ranking-list v-if="chineselist.length > 0" :rankinglist="chineselist"></ranking-list>
        <van-loading v-else size="24px" vertical text-color="#0094ff" color="#0094ff"
            >加载中...</van-loading
        >
    </div>
</template>

<script>
import RankingList from "@/components/RankingList.vue";
// 1 free 3 manga 4 chinese
export default {
    components: { RankingList },
    data() {
        return {
            chineselist: [],
        };
    },
    created() {
        this.getchineselist();
    },
    methods: {
        async getchineselist() {
            await this.axios.get("GetRankInfo?id=1").then((res) => {
                this.chineselist = res.list;
            });
        },
    },
};
</script>

<style lang="scss" scoped></style>
