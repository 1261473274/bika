<template>
    <div>
        <div class="typeSeven">
            <div class="title">
                <h2>{{ todayHot.name }}</h2>
            </div>
            <home-list :typeSeven="typeSeven"></home-list>
        </div>
    </div>
</template>

<script>
import HomeList from "./homeList.vue";
export default {
    components: { HomeList },
    props: {
        todayHot: {
            type: Object,
            default: () => {
                return null;
            },
        },
        typeSeven: {
            type: Array,
            default: () => {
                return [];
            },
        },
    },
};
</script>

<style lang="scss" scoped>
.typeSeven {
    height: 112vh;
    margin: 20px 15px;
    position: relative;
    .title {
        display: flex;
        justify-content: space-between;
        align-content: center;
        h2 {
            font-weight: bold;
            font-size: 18px;
        }
        p {
            font-size: 14px;
            color: rgba(0, 0, 0, 0.5);
        }
    }
    .loading {
        position: absolute;
        left: 0;
        right: 0;
        top: 35vh;
    }
}
</style>
