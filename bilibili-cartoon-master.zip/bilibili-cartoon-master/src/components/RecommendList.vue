<template>
    <div class="list">
        <ul class="feeds" v-if="feedList.length > 0">
            <router-link
                tag="li"
                :to="`/details/${item.item_id}`"
                v-for="(item, index) in feedList"
                :key="index"
            >
                <van-image
                    width="44vw"
                    height="58.6vw"
                    lazy-load
                    fit="cover"
                    :src="`${item.image}@200w.jpg`"
                />
                <div class="title">{{ item.title }}</div>
                <div class="left" v-if="item.comic_info.decision !== ''">
                    {{ item.comic_info.decision }}
                </div>
                <div v-else class="right">{{ item.comic_info.main_style_name }}</div>
            </router-link>
        </ul>
    </div>
</template>

<script>
export default {
    props: {
        feedList: {
            type: Array,
            default: () => {
                return [];
            },
        },
    },
};
</script>

<style lang="scss" scoped>
.list {
    position: relative;
    .feeds {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        padding: 0 16px;
        li {
            padding: 15px 0;
            .title {
                width: 35vw;
                font-size: 14px;
                font-weight: bold;
                color: #212121;
                opacity: 0.8;
                white-space: nowrap;
                text-overflow: ellipsis;
                overflow: hidden;
                padding-top: 5px;
                padding-left: 10px;
            }
            .left {
                margin-top: 3px;
                font-size: 12px;
                color: #fdc56f;
                padding: 5px 10px;
                display: inline-block;
                background: #fffbf2;
                padding-left: 10px;
            }
            .right {
                margin-top: 3px;
                font-size: 12px;
                color: #b8bbbf;
                padding-left: 10px;
                display: inline-block;
            }
        }
    }
    .loading {
        margin-bottom: 50px;
    }
}
</style>
