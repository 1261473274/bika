<template>
    <div class="voice_cartoon"></div>
</template>

<script>
export default {};
</script>

<style></style>
