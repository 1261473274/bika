<template>
    <div class="nav">
        <van-tabbar route>
            <van-tabbar-item replace to="/">
                <div class="iconfont icon-31shouye"></div>
                首页
            </van-tabbar-item>
            <van-tabbar-item replace to="/classify">
                <div class="iconfont fenlei icon-fenleiorguangchangorqita"></div>
                分类
            </van-tabbar-item>
            <van-tabbar-item replace to="/collect">
                <div class="iconfont icon-shujia"></div>
                书架
            </van-tabbar-item>
            <van-tabbar-item replace to="/user">
                <div class="iconfont icon-wode"></div>
                我的
            </van-tabbar-item>
        </van-tabbar>
    </div>
</template>

<script>
export default {
    data() {
        return {
            active: 0,
        };
    },
};
</script>

<style lang="scss" scoped>
.iconfont {
    text-align: center;
    font-size: 24px;
    cursor: pointer;
}
.fenlei {
    font-size: 18px;
}
</style>
