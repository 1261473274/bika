<template>
    <!-- 正能量页面 -->
    <div class="energy">
        <div class="swipe">
            <swiper :options="swiperOptions" class="swiper">
                <swiper-slide v-for="b in bannerList" :key="b.image_url">
                    <router-link
                        :to="
                            b.jump_url.includes('bilicomic')
                                ? b.jump_url.split('bilicomic:/')[1].replace('detail', 'details')
                                : ''
                        "
                        tag="div"
                    >
                        <van-image
                            width="46vw"
                            height="61.3vw"
                            radius="5px"
                            lazy-load
                            fit="cover"
                            :src="`${b.image_url}@300w.jpg`"
                        />
                    </router-link>
                </swiper-slide>
            </swiper>
        </div>
        <div class="energy_content" v-if="energyList">
            <type-three
                :todayHot="energyList[2]"
                :typeThreeID="typeThreeID[0]"
                :typeThree="typeThree[0]"
            ></type-three>
            <type-three
                :todayHot="energyList[3]"
                :typeThreeID="typeThreeID[1]"
                :typeThree="typeThree[1]"
            ></type-three>
            <type-three
                :todayHot="energyList[5]"
                :typeThreeID="typeThreeID[2]"
                :typeThree="typeThree[2]"
            ></type-three>
            <type-three
                :todayHot="energyList[6]"
                :typeThreeID="typeThreeID[3]"
                :typeThree="typeThree[3]"
            ></type-three>
            <type-three
                :todayHot="energyList[7]"
                :typeThreeID="typeThreeID[4]"
                :typeThree="typeThree[4]"
            ></type-three>
            <type-three
                :todayHot="energyList[8]"
                :typeThreeID="typeThreeID[5]"
                :typeThree="typeThree[5]"
            ></type-three>
        </div>
        <van-loading v-else size="24px" vertical text-color="#0094ff" color="#0094ff"
            >加载中...</van-loading
        >
        <div class="more" v-if="ismore">没有更多啦~</div>
    </div>
</template>

<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/css/swiper.css";
import TypeThree from "./typeThree.vue";
export default {
    components: { Swiper, SwiperSlide, TypeThree },
    data() {
        return {
            bannerList: [],
            energyList: [],
            typeThree: [],
            typeThreeID: [],
            ismore: false,
            swiperOptions: {
                //swiper轮播图配置
                speed: 2000,
                autoplay: {
                    delay: 0,
                    stopOnLastSlide: false,
                    disableOnInteraction: false,
                },
                slidesPerView: 2,
                spaceBetween: 30,
                centeredSlides: true,
                pauseOnMouseEnter: true,
                parallax: true,
                loop: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
            },
        };
    },
    created() {
        this.getEnergyList();
    },
    methods: {
        async getEnergyList() {
            await this.axios.get(`GetClassPageLayout?tabId=47`).then((res) => {
                this.energyList = res.layout;
                this.getBannerList();
                this.getTypeThree();
            });
        },
        async getBannerList() {
            for (let i = 0; i < this.energyList.length; i++) {
                if (this.energyList[i].type == "0") {
                    await this.axios
                        .get(`GetClassPageHomeBanner?id=${this.energyList[i].id}`)
                        .then((res) => {
                            this.bannerList = res.banner;
                        });
                }
            }
        },
        async getTypeThree() {
            for (let i = 0; i < this.energyList.length; i++) {
                if (this.energyList[i].type == "3") {
                    this.typeThreeID.push(this.energyList[i].id);
                    await this.axios
                        .get(
                            `GetClassPageSixComics?id=${this.energyList[i].id}&pageNum=1&pageSize=6&isAll=0`
                        )
                        .then((res) => {
                            if (res.roll_six_comics.length == 0) {
                                return;
                            }
                            this.typeThree.push(res.roll_six_comics);
                            this.ismore = true;
                        });
                }
            }
        },
    },
};
</script>

<style lang="scss" scoped>
.swiper {
    text-align: center;
    margin-top: 20px;
    img {
        width: 100%;
        border-radius: 10px;
    }
}
.more {
    text-align: center;
    height: 30px;
    line-height: 30px;
    opacity: 0.8;
}
</style>
