<template>
    <div id="app">
        <nav-bar v-if="!$route.meta.hideNav"></nav-bar>
        <router-view />
    </div>
</template>
<script>
import NavBar from "@/components/NavBar.vue";

export default {
    data() {
        return {};
    },
    components: { NavBar },
    methods: {},
};
</script>

<style lang="scss" scoped></style>
